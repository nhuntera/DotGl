import DotGL
import time
import random

draw = DotGL.screen(180,52,False)

draw.debug()

draw.pixel(90,26)
draw.pixel(90,-25)
draw.pixel(-90,26)
draw.pixel(-90,-25)
ballx=0
bally=0
ballxm=1
ballym=0
while(True):

    time.sleep(.01)
    draw.pixel(90,26)
    draw.pixel(90,-25)
    draw.pixel(-90,26)
    draw.pixel(-90,-25)
    if ballx < -89:
        ballxm=1
        ballym=random.triangular(-1,1,0)
    if ballx > 89:
        ballxm=-1
        ballym=random.triangular(-1,1,0)
    if bally < -24 or bally > 24: ballym = ballym *-1
    ballx= ballx + ballxm
    bally= bally + ballym

    draw.pixel(ballx,int(bally))
    draw.update()