import DotGL
import time

draw = DotGL.screen(180,52,False)

draw.debug()


while(True):
    time.sleep(1)
    draw.draw_line(0,10,0,15)
    #draw.update()
    draw.draw_line(10,0,15,0)
    draw.update()
